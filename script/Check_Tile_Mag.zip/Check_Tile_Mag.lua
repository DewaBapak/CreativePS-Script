for _, tile in pairs(GetTiles ()) do
if tile.fg==5638 then
LogToConsole("`2[YASU-LOG] > `5Found!")
LogToConsole("`1~~~~~~~~~~~~~~~~~~~~~~~")
LogToConsole("x = "..tile.x)
LogToConsole("y = "..tile.y)
LogToConsole("`1~~~~~~~~~~~~~~~~~~~~~~~")
end
end